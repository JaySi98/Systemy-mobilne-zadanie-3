package com.example.zad_1;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Question
{
    private int question_id;
    private boolean true_answer;

    public Question(int question_id, boolean true_answer)
    {
        this.question_id = question_id;
        this.true_answer = true_answer;
    }

    public boolean isTrueAnswer()
    {
        return true_answer;
    }

}
