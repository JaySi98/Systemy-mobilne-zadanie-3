package com.example.zad_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class PromptActivity extends AppCompatActivity {
    public static final String KEY_EXTRA_SHOWN = "answerShown";

    private boolean correctAnswer;

    private Button show_prompt_button;
    private TextView text_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prompt);

        show_prompt_button = findViewById(R.id.show_prompt_button);
        text_view = findViewById(R.id.textView1);

        correctAnswer = getIntent().getBooleanExtra(MainActivity.KEY_EXTRA_ANSWER, true);

        show_prompt_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int answer = correctAnswer ? R.string.button_true : R.string.button_false;
                text_view.setText(answer);

                setAnswerShownResult(true);
            }
        });
    }

    private void setAnswerShownResult(boolean answerWasShown)
    {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(KEY_EXTRA_SHOWN, answerWasShown);
        setResult(RESULT_OK, resultIntent);
    }
}