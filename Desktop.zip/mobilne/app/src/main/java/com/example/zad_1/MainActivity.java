package com.example.zad_1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private static final String QUIZ_TAG = "Main Activity";
    private static final String KEY_CURRENT_INDEX = "current Index";
    public static final String KEY_EXTRA_ANSWER = "correctAnswer";
    private static final int REQUEST_CODE_PROMPT = 0;
    private boolean answerWasShown = false;

    private Button true_button;
    private Button false_button;
    private Button next_button;
    private Button prompt_button;
    private TextView text_view;

    private Question questions []= {
            new Question(R.string.q_1, true),
            new Question(R.string.q_2, true),
            new Question(R.string.q_3, false),
            new Question(R.string.q_4, true),
            new Question(R.string.q_5, false)
    };
    private int index = 0;

    private void check_answer(boolean user_answer)
    {
        boolean correct_answer = questions[index].isTrue_answer();
        int result_message_id = 0;
        if(answerWasShown){
            result_message_id = R.string.answer_was_shown;
        }
        else {
            if (user_answer == correct_answer) {
                result_message_id = R.string.correct_answer;
            } else {
                result_message_id = R.string.incorrect_answer;
            }
        }
        Toast.makeText(this, result_message_id, Toast.LENGTH_SHORT).show();
    }


    private void set_question()
    {
        text_view.setText(questions[index].getQuestion_id());
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(QUIZ_TAG, "onCreate");

        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            index = savedInstanceState.getInt(KEY_CURRENT_INDEX);
        }

        true_button = findViewById(R.id.true_button);
        false_button = findViewById(R.id.false_button);
        next_button = findViewById(R.id.next_button);
        prompt_button = findViewById(R.id.prompt_button);
        text_view = findViewById(R.id.question_text_view);

        true_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_answer(true);
            }
        });

        false_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_answer(false);
            }
        });

        next_button.setOnClickListener(v ->  {
                index = (index + 1) % questions.length;
                answerWasShown = false;
                set_question();
        });
        set_question();

        prompt_button.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PromptActivity.class);
            boolean correctAnswer = questions[index].isTrueAnswer();
            intent.putExtra(KEY_EXTRA_ANSWER, correctAnswer);
            startActivityForResult(intent, REQUEST_CODE_PROMPT);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode != RESULT_OK) {return;}
        if(requestCode == REQUEST_CODE_PROMPT)
        {
            if(data == null){return;}
            answerWasShown = data.getBooleanExtra(PromptActivity.KEY_EXTRA_SHOWN, false);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(QUIZ_TAG, "onSaveInstanceState");
        outState.putInt(KEY_CURRENT_INDEX, index);
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(QUIZ_TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(QUIZ_TAG, "onDestroy");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(QUIZ_TAG, "onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(QUIZ_TAG, "onResume");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(QUIZ_TAG, "onStart");
    }
}
